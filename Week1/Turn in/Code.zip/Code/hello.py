print("Hello, World!\n")
print("Dan Beck");
print("SDEV-325");
print("August 22, 2020");
print("Excited to be coding again");