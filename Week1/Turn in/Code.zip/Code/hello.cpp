#include <stdio.h>

int main(void)
{
    printf("Hello, World!\n\n");
    
    //Signature
    printf("Dan Beck\n");
    printf("SDEV-325\n");
    printf("August 22, 2020\n");
    printf("Excited to be coding again\n");
}