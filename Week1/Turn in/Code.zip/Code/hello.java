public class hello 
{
    public static void main(String[] args) 
    {
        System.out.println("Hello, World!\n");
        //Signature
        System.out.println("Dan Beck");
        System.out.println("SDEV-325");
        System.out.println("August 22, 2020");
        System.out.println("Excited to be coding again");
    }
}